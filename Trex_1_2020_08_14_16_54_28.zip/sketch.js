var trex, runningtrex, collidedtrex;
var ground, ground2, groundimage;
var cloud,cloudimage,cloudGroups;



function setup() {
  createCanvas(400, 400);
  trex = createSprite(200, 380, 20, 50);
  trex.x = 50;
  trex.addAnimation("runningtrex", runningtrex);
  trex.scale = 0.5;
  ground = createSprite(200, 380, 400, 20);
  ground.addImage("ground2", groundimage);
  ground.x = ground.width / 2;
  ground2 = createSprite(200, 385, 400, 5);
  ground2.visible = false;
  
  cloudGroups=new Group();
  
}

function draw() {
  background(255);
  trex.collide(ground2);
  ground.velocityX = -3;

  if (ground.x < 0) {
    ground.x = ground.width / 2;
  }

  if (keyDown("space")) {
    trex.velocityY = -12;
  }

  trex.velocityY = trex.velocityY + 0.8;
  
  spawnClouds();
  drawSprites();
}

function preload() {
  runningtrex = loadAnimation("trex1.png", "trex3.png", "trex4.png");
  groundimage = loadImage("ground2.png");
  cloudimage=loadImage("cloud.png");
}

function spawnClouds(){
  //write code here to spawn the clouds
  if (World.frameCount % 60 === 0) {
    var cloud = createSprite(400,320,40,10);
    cloud.y = random(280,320);
    cloud.addImage("cloud",cloudimage);
    cloud.scale = 0.5;
    cloud.velocityX = -3;
    
     //assign lifetime to the variable
    cloud.lifetime = 134;
    
    //adjust the depth
    cloud.depth = trex.depth;
    trex.depth = trex.depth + 1;
    
    //add each cloud to the group
    cloudGroups.add(cloud);
  }
}